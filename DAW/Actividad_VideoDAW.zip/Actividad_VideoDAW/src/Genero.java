public enum Genero {
    ACCION,
    AVENTURA,
    CATASTROFE,
    CIENCIA_FICCION,
    COMEDIA,
    DOCUMENTALES,
    DRAMA,
    FANTASIA
}

